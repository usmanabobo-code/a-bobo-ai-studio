package com.abobo.aivideo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF10101C)
private val Panel = Color(0xFF1B1B2B)
private val Purple = Color(0xFF8B5CF6)
private val Cyan = Color(0xFF22D3EE)
private val Muted = Color(0xFFAAA9BD)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StudioApp() }
    }
}

@Composable
fun StudioApp() {
    var tab by remember { mutableStateOf("Home") }
    var prompt by remember { mutableStateOf("") }
    var style by remember { mutableStateOf("Cinematic") }
    var ratio by remember { mutableStateOf("9:16") }
    var selectedImage by remember { mutableStateOf<String?>(null) }
    var notice by remember { mutableStateOf("Welcome to A Bobo AI Studio") }
    var showPlan by remember { mutableStateOf(false) }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) {
        selectedImage = it?.toString()
        if (it != null) notice = "Image selected. Connect a video provider to animate it."
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Purple,
        secondary = Cyan, onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Ink,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    listOf("Home", "Create", "Projects", "Profile").forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = {
                                Icon(
                                    when(item) {
                                        "Home" -> Icons.Default.Home
                                        "Create" -> Icons.Default.AutoAwesome
                                        "Projects" -> Icons.Default.VideoLibrary
                                        else -> Icons.Default.Person
                                    }, contentDescription = item
                                )
                            },
                            label = { Text(item) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Cyan,
                                selectedTextColor = Cyan,
                                indicatorColor = Purple.copy(alpha = .22f),
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            when(tab) {
                "Home" -> HomeScreen(padding, onCreate = { tab = "Create" }, onPlans = { showPlan = true })
                "Create" -> CreateScreen(
                    padding, prompt, { prompt = it }, style, { style = it },
                    ratio, { ratio = it }, selectedImage,
                    { imagePicker.launch("image/*") },
                    { notice = "Your request is ready. Add a real AI video API in the backend configuration to generate videos." }
                )
                "Projects" -> ProjectsScreen(padding)
                else -> ProfileScreen(padding, onPlans = { showPlan = true })
            }
        }
        if (showPlan) {
            AlertDialog(
                onDismissRequest = { showPlan = false },
                title = { Text("Choose your plan") },
                text = { Text("Free: basic tools and limited credits. Premium: higher generation limits and advanced features. Payments will be activated after a payment provider is configured.") },
                confirmButton = { TextButton(onClick = { showPlan = false }) { Text("Got it") } }
            )
        }
        LaunchedEffect(notice) {
            // Notice is intentionally retained as app state for future snackbar integration.
        }
    }
}

@Composable
fun HomeScreen(padding: PaddingValues, onCreate: () -> Unit, onPlans: () -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("A BOBO", color = Cyan, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                    Text("AI STUDIO", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
                }
                Surface(color = Panel, shape = RoundedCornerShape(50)) {
                    Text("FREE PLAN", modifier = Modifier.padding(horizontal = 13.dp, vertical = 8.dp),
                        color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        item {
            Box(
                Modifier.fillMaxWidth().background(
                    Brush.linearGradient(listOf(Color(0xFF4C1D95), Color(0xFF172554), Color(0xFF0E7490))),
                    RoundedCornerShape(26.dp)
                ).padding(22.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Your imagination.\nAI-powered videos.", fontSize = 28.sp, lineHeight = 34.sp,
                        fontWeight = FontWeight.ExtraBold, color = Color.White)
                    Text("Turn simple ideas into captivating video concepts.", color = Color.White.copy(.8f))
                    Button(onClick = onCreate, colors = ButtonDefaults.buttonColors(containerColor = Color.White)) {
                        Text("Create a video", color = Color(0xFF27134F), fontWeight = FontWeight.Bold)
                        Spacer(Modifier.width(8.dp))
                        Icon(Icons.Default.ArrowForward, null, tint = Color(0xFF27134F))
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("DAILY FREE VIDEOS", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    Text("2 videos every day", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("Your allowance resets daily", color = Muted, fontSize = 12.sp)
                }
                Icon(Icons.Default.ConfirmationNumber, contentDescription = null, tint = Cyan, modifier = Modifier.size(30.dp))
            }
        }
        item { Text("CREATE WITH AI", color = Muted, fontWeight = FontWeight.Bold, letterSpacing = 2.sp) }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                FeatureCard(Icons.Default.Edit, "Text to Video", "Describe your idea and plan a video")
                FeatureCard(Icons.Default.Image, "Image to Video", "Animate a photo with AI")
                FeatureCard(Icons.Default.AutoStories, "Script to Video", "Turn a story into scenes and narration")
                FeatureCard(Icons.Default.RecordVoiceOver, "AI Voiceover", "Prepare narration in your language")
            }
        }
        item {
            OutlinedButton(onClick = onPlans, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.WorkspacePremium, null)
                Spacer(Modifier.width(8.dp))
                Text("Explore Premium plans")
            }
        }
        item { Text("AI video generation requires a connected provider. Your app is ready for integration.", color = Muted, fontSize = 12.sp) }
    }
}

@Composable
fun FeatureCard(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, description: String) {
    Row(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(46.dp).background(Purple.copy(.18f), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Cyan)
        }
        Spacer(Modifier.width(14.dp))
        Column {
            Text(title, fontWeight = FontWeight.Bold)
            Text(description, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
fun CreateScreen(
    padding: PaddingValues, prompt: String, onPrompt: (String) -> Unit,
    style: String, onStyle: (String) -> Unit, ratio: String, onRatio: (String) -> Unit,
    imageUri: String?, onPickImage: () -> Unit, onGenerate: () -> Unit
) {
    LazyColumn(
        Modifier.fillMaxSize().padding(padding).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Text("Create your video", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold) }
        item { Text("Describe the video you want to make.", color = Muted) }
        item {
            OutlinedTextField(
                value = prompt, onValueChange = onPrompt,
                modifier = Modifier.fillMaxWidth().heightIn(min = 150.dp),
                placeholder = { Text("Example: A cinematic drone shot over a beautiful African city at sunset...") },
                label = { Text("Your video prompt") },
                shape = RoundedCornerShape(18.dp)
            )
        }
        item {
            OutlinedButton(onClick = onPickImage, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.AddPhotoAlternate, null)
                Spacer(Modifier.width(8.dp))
                Text(if (imageUri == null) "Choose an image" else "Image selected")
            }
        }
        item { Text("VIDEO STYLE", color = Muted, fontWeight = FontWeight.Bold) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Cinematic", "3D Cartoon", "Anime").forEach {
                    FilterChip(selected = style == it, onClick = { onStyle(it) }, label = { Text(it) })
                }
            }
        }
        item { Text("ASPECT RATIO", color = Muted, fontWeight = FontWeight.Bold) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("9:16", "16:9", "1:1").forEach {
                    FilterChip(selected = ratio == it, onClick = { onRatio(it) }, label = { Text(it) })
                }
            }
        }
        item {
            Button(
                onClick = onGenerate,
                enabled = prompt.isNotBlank() || imageUri != null,
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Default.AutoAwesome, null)
                Spacer(Modifier.width(8.dp))
                Text("Prepare AI video", fontWeight = FontWeight.Bold)
            }
        }
        item { Text("Free plan: 2 video generations per day. The secure backend must enforce this limit; the app UI alone cannot prevent quota abuse. AI generation becomes available after a provider is connected.", color = Muted, fontSize = 12.sp) }
    }
}

@Composable
fun ProjectsScreen(padding: PaddingValues) {
    Column(Modifier.fillMaxSize().padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("My projects", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
        Text("Your generated videos and drafts will appear here after cloud storage is connected.", color = Muted)
        Box(Modifier.fillMaxWidth().padding(top = 30.dp), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.VideoLibrary, null, tint = Purple, modifier = Modifier.size(54.dp))
                Spacer(Modifier.height(12.dp))
                Text("No projects yet", fontWeight = FontWeight.Bold)
                Text("Create your first video to get started.", color = Muted)
            }
        }
    }
}

@Composable
fun ProfileScreen(padding: PaddingValues, onPlans: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Text("Your account", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
        FeatureCard(Icons.Default.Person, "Guest profile", "Authentication will be enabled with Supabase.")
        FeatureCard(Icons.Default.Bolt, "Free credits", "Credit balance appears here after backend setup.")
        Button(onClick = onPlans, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.WorkspacePremium, null)
            Spacer(Modifier.width(8.dp))
            Text("View plans")
        }
        Text("A Bobo AI Studio • Version 1.0.0", color = Muted, fontSize = 12.sp)
    }
}
