# A Bobo AI Studio — Android starter project

This is a native Android (Kotlin + Jetpack Compose) starter application for A Bobo AI Studio.

## Included now
- Dark purple/cyan mobile UI
- Home dashboard
- Create-video screen
- Prompt input and style selection
- Image picker
- Aspect-ratio selection
- Projects and profile screens
- Free/Premium plan information screen
- Android navigation

## Important: AI generation is not yet live
The app UI is functional, but actual video generation, account sync, cloud storage, subscriptions, and credit enforcement require a backend and a video-generation provider. This project deliberately does not fake completed AI videos or embed secret API keys.

## Build in Android Studio
1. Install the latest stable Android Studio.
2. Open this project folder.
3. Allow Gradle sync to complete.
4. Use JDK 17.
5. Connect an Android phone with USB debugging or create an emulator (API 26+).
6. Press Run.

The project targets Android SDK 35 and uses Kotlin, Jetpack Compose, and Material 3.

## Production implementation plan

### Phase 1 — Android foundation
- Complete UI/UX and navigation
- Add DataStore for local preferences
- Add local draft persistence and video playback
- Add upload validation and progress UI

### Phase 2 — Backend
Recommended backend: Supabase + a server-side API (Ktor, Node.js, or Supabase Edge Functions).
Create tables:
- profiles(id, display_name, created_at)
- credit_wallets(user_id, balance, daily_video_count, daily_reset_at, updated_at)
- credit_transactions(id, user_id, amount, reason, job_id, created_at)
- video_jobs(id, user_id, provider, prompt, style, aspect_ratio, status, output_url, error, created_at)
- subscriptions(id, user_id, plan, status, expires_at)

Use row-level security so users can only read their own records. Only trusted server code may change credit balances.

### Phase 3 — AI video provider
Select a provider that offers text-to-video and/or image-to-video APIs. Implement server-side endpoints:
- POST /video-jobs — validate user, prompt, and provider limits; atomically enforce the 2-per-day free quota (reset by server date/timezone policy); reserve credits; create provider job. Never trust a client-side counter.
- GET /video-jobs/{id} — return job status.
- POST /video-jobs/{id}/complete — internal webhook; verify provider signature, store output, settle credits.
- POST /video-jobs/{id}/retry — retry safely and avoid duplicate charges.

Never call paid provider APIs directly from the Android client. Keep provider keys in server secrets.

### Phase 4 — Free and Premium plans
- Free plan: exactly 2 video-generation jobs per user per day by default, basic styles, provider-dependent duration/resolution. Make the limit configurable from the server/admin settings.
- Premium: larger credit allowance and advanced options.
- Display exact credit cost before generation.
- Use Google Play Billing for Android digital subscriptions and validate purchases on the backend.
- Refund reserved credits on failed jobs.

### Phase 5 — Release
- Add privacy policy, terms, account deletion, moderation/reporting, and support contact.
- Test on low-memory Android devices and slow networks.
- Add crash reporting and analytics with consent.
- Create signed Android App Bundle (AAB) for Google Play.

## Configuration still required
- Supabase project URL and anon key (anon key can be in client only with correct RLS; service-role key must never be in client)
- Secure backend URL
- Video provider account and API key stored only on backend
- Google Play developer account and billing products for Premium

## Current limitations
This source package is not a compiled APK/AAB. It is an Android Studio project. A configured Android build environment is needed to compile and sign it.


## Free daily video quota
The product default is **2 generated videos per user per day** on the Free plan. This is displayed in the Android UI. Production enforcement must happen atomically on the backend (database transaction/RPC), not on the device, so reinstalling the app or changing device time cannot reset the quota. Failed provider jobs should restore the reserved allowance/credits according to the published policy. Premium limits should be configured separately.


## Build an APK using only your Android phone

This repository includes `.github/workflows/android.yml` so GitHub can compile the APK in the cloud.

1. Create a GitHub repository named `a-bobo-ai-studio`.
2. Upload the project files and folders to the repository (upload the contents, not the ZIP file itself).
3. Open the repository's **Actions** tab.
4. Select **Build A Bobo AI Studio APK**.
5. Tap **Run workflow** if it has not started automatically.
6. Open the completed workflow run.
7. Under **Artifacts**, download `A-Bobo-AI-Studio-debug-APK`.
8. Extract the downloaded artifact ZIP and install `app-debug.apk` on your Android phone. You may need to allow installation from your browser or file manager.

A debug APK is for testing, not Google Play publication. A signed release AAB/APK, privacy policy, provider integration, and production security review are still required before launch.

### Mobile browser tips
Use Chrome's **Desktop site** option if GitHub's upload or Actions controls are difficult to see on a phone. Keep the project ZIP backed up on your device.
