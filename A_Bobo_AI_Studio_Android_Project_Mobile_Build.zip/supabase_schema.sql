-- Supabase starter schema for A Bobo AI Studio. Review and apply in a test project first.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  plan text not null default 'free' check (plan in ('free','premium')),
  created_at timestamptz not null default now()
);

create table if not exists public.video_jobs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  prompt text not null,
  style text not null default 'Cinematic',
  aspect_ratio text not null default '9:16',
  status text not null default 'queued' check (status in ('queued','processing','completed','failed')),
  output_url text,
  provider_job_id text,
  created_at timestamptz not null default now()
);

create index if not exists video_jobs_user_created_idx on public.video_jobs(user_id, created_at desc);
alter table public.profiles enable row level security;
alter table public.video_jobs enable row level security;
create policy "Users read own profile" on public.profiles for select using (auth.uid() = id);
create policy "Users read own video jobs" on public.video_jobs for select using (auth.uid() = user_id);
-- Only trusted backend/service-role code should insert/update jobs and enforce the daily quota.
